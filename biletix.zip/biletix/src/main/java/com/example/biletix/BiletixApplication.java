package com.example.biletix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiletixApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiletixApplication.class, args);
	}
}

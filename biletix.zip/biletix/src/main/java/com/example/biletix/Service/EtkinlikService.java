package com.example.biletix.Service;

public class EtkinlikService {
}

package com.example.biletix.Model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@Table(name = "kategori")
public class Kategori {
    String kategoriAd;


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long kategoriId;

    @OneToMany(mappedBy = "kategori")
    List<Etkinlik> etkinliks;

}

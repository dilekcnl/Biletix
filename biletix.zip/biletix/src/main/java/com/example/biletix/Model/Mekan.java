package com.example.biletix.Model;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Table(name = "mekan")
public class Mekan {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long mekanId;
    String mekanAd;

    @OneToMany(mappedBy = "mekan")
    List<Bilet> bilets;
}

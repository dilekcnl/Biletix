package com.example.biletix.Model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "sehir")
public class Sehir {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long sehirId;
    String sehirAd;
}

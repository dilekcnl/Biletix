package com.example.biletix.Repository;

public class EtkinlikRepository {
}

package com.example.biletix.Model;

import lombok.Data;

import javax.persistence.*;
import java.sql.Time;
import java.util.Date;
import java.util.List;

@Entity
@Data
@Table(name = "etkinlik")
public class Etkinlik {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long etkinlikId;
    String etkinlikAd;
    Date etkinlikTrh;
    Time etkinlikSaat;

    @ManyToOne
    @JoinColumn(name = "kategori")
    Kategori kategori;
}
